http://mit-license.org/
